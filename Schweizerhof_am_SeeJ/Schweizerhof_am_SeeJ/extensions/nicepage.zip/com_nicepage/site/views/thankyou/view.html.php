<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use NP\Factory as NpFactory;

class NicepageViewThankyou extends BaseHtmlView
{
    /**
     * @param null $tpl
     *
     * @return mixed
     */
    public function display($tpl = null)
    {
        $template = NpFactory::getTemplate('ThankYou');
        $template->buildPageElements();
        $this->html = $template->getHtml();
        return parent::display($tpl);
    }
}
