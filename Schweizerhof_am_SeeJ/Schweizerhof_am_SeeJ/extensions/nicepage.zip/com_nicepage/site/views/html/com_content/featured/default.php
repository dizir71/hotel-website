<?php
defined('_JEXEC') or die;

require_once dirname(dirname(__FILE__)) . '/category/blog.php';
