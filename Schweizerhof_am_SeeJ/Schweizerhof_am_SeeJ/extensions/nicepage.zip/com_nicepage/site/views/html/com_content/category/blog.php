<?php

use NP\Factory as NpFactory;

$data = array(
    'lead_items' => $this->lead_items,
    'intro_items' => $this->intro_items,
    'pagination' => $this->pagination,
);

$page = NpFactory::getTemplate('blog');
$page->setTemplateData($data);
$page->buildPageElements();
echo $page->getHtml();
