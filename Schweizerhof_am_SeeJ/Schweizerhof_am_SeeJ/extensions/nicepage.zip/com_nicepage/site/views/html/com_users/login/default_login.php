<?php

use NP\Factory as NpFactory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;

ob_start();
?>
<?php $return = $this->form->getValue('return', '', $this->params->get('login_redirect_url', $this->params->get('login_redirect_menuitem'))); ?>
    <input type="hidden" name="return" value="<?php echo base64_encode($return); ?>" />
<?php echo HTMLHelper::_('form.token'); ?>
<?php
$hiddenFields = ob_get_clean();
$loginFormAction = Route::_('index.php?option=com_users&task=user.login');
$loginRemindAction = Route::_('index.php?option=com_users&view=remind');
$loginResetAction = Route::_('index.php?option=com_users&view=reset');

$usersConfig = ComponentHelper::getParams('com_users');
$loginRegistrationAllow = $usersConfig->get('allowUserRegistration');
$loginRegistrationAction = Route::_('index.php?option=com_users&view=registration');

$loginFormRememberEnabled = PluginHelper::isEnabled('system', 'remember');
$submitText = Text::_('JSUBMIT');
$data = array(
    'hidden_fields' => $hiddenFields,
    'login_form_action' => $loginFormAction,
    'submit_text' => $submitText,
    'login_remind_action' => $loginRemindAction,
    'login_reset_action' => $loginResetAction,
    'login_registration_allow' => $loginRegistrationAllow,
    'login_registration_action' => $loginRegistrationAction,
    'login_form_remember_enabled' => $loginFormRememberEnabled,
);

$page = NpFactory::getTemplate('login');
$page->setTemplateData($data);
$page->buildPageElements();
echo $page->getHtml();
