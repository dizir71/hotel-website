<?php
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use NP\Factory as NpFactory;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('behavior.formvalidator');

$page = NpFactory::getTemplate('login');
$page->setTemplateData(
    array(
        'loginFormClassPlaceholder' => true,
        'loginFormLogoutPlaceholder' => true,
        'loginFormUsernameGroupTemplate' => true,
    )
);
$page->buildPageElements();
$html = $page->getHtml();

$formClass = '';
if (preg_match('/<\!--loginFormClassPlaceholder-->([\s\S]+?)<\!--\/loginFormClassPlaceholder-->/', $html, $matches)) {
    $formClass = $matches[1];
}

$formSubmit = '';
if (preg_match('/<\!--loginFormLogoutPlaceholder-->([\s\S]+?)<\!--\/loginFormLogoutPlaceholder-->/', $html, $matches)) {
    $formSubmit = $matches[1];
    $formSubmit = preg_replace('/(<a[^>]+?>)([\s\S]*?)(<\/a>)/', '$1' . Text::_('JSUBMIT') . '$3', $formSubmit);
}

$inputHtml = '';
if (preg_match('/<\!--loginFormUsernameGroupTemplate-->([\s\S]+?)<\!--\/loginFormUsernameGroupTemplate-->/', $html, $matches)) {
    $inputHtml = $matches[1];
}
?>
<section class="u-clearfix">
    <div class="u-clearfix u-sheet">
        <div class="reset<?php echo $this->pageclass_sfx; ?>">
            <?php if ($this->params->get('show_page_heading')) : ?>
                <div class="page-header">
                    <h1>
                        <?php echo $this->escape($this->params->get('page_heading')); ?>
                    </h1>
                </div>
            <?php endif; ?>
            <div class="u-form">
                <form id="user-registration" action="<?php echo Route::_('index.php?option=com_users&task=reset.request'); ?>" method="post" class="<?php echo $formClass ? $formClass : 'form-validate form-horizontal well'; ?>">
                    <?php
                    foreach ($this->form->getFieldsets() as $fieldset) {
                        if (isset($fieldset->label)) {
                            echo '<p>' . Text::_($fieldset->label) . '</p>';
                        }
                        if ($inputHtml) {
                            $fields = $this->form->getFieldset($fieldset->name);
                            foreach ($fields as $field) {
                                if ($field->id === 'jform_captcha') {
                                    echo '<div class="u-form-group">';
                                    echo $field->renderField();
                                    echo '<div/>';
                                } else {
                                    echo str_replace(
                                        array('[[label_for]]', '[[label_name]]', '[[label_content]]', '[[input_type]]', '[[input_placeholder]]', '[[input_id]]', '[[input_name]]'),
                                        array($field->id, $field->id . '-lbl', $field->title, $field->type, '', $field->id, $field->name),
                                        $inputHtml
                                    );
                                }
                            }
                        } else {
                            echo $this->form->renderFieldset($fieldset->name);
                        }
                    }
                    ?>
                    <?php if ($formSubmit) : ?>
                        <?php echo $formSubmit; ?>
                    <?php else: ?>
                        <div class="control-group">
                            <div class="controls">
                                <button type="submit" class="btn btn-primary validate">
                                    <?php echo Text::_('JSUBMIT'); ?>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php echo HTMLHelper::_('form.token'); ?>
                </form>
            </div>
        </div>
    </div>
</section>
