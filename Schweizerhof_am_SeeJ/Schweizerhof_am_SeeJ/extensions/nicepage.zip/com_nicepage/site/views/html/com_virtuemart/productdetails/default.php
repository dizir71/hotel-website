<?php

use NP\Factory as NpFactory;

$data = array(
    'product' => $this->product,
);

$page = NpFactory::getTemplate('product');
$page->setTemplateData($data);
$page->buildPageElements();
echo $page->getHtml();
