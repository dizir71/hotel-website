<?php

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use NP\Factory as NpFactory;

$app = Factory::getApplication();
$template = $app->getTemplate(true);

$funcPath = JPATH_SITE . '/templates/' . $template->template . '/functions.php';
if (File::exists($funcPath)) {
    include_once $funcPath;
}

$orderByList = array();
if (class_exists('Core')) {
    Core::load("Core_Content");
    $component = new CoreContent($this);
    $orderByList = !empty($this->orderByList) && isset($this->orderByList['orderby']) ? $this->orderByList['orderby'] : '';
}

$isFeaturedProducts = vRequest::getInt('featured', '0');
if ($isFeaturedProducts === '1') {
    $productModel = VmModel::getModel('Product');
    $productModel::$omitLoaded = false;
    $items = $productModel->getProductListing(
        'featured',
        25,
        true,
        true,
        false,
        false,
        '0',
        false,
        null,
    );
    $this->products = array('products' => $items);
}

if (count($this->products) > 0 && array_key_exists(0, $this->products)) {
    $p = $this->products;
    $this->products = array();
    $this->products[0] = $p;
}

$productCollections = array_filter(
    $this->products,
    function ($collection) {
        return count($collection) > 0;
    }
);

$data = array(
    'products' => $productCollections,
    'orderByList' => $orderByList,
);

$page = NpFactory::getTemplate('products');
$page->setTemplateData($data);
$page->buildPageElements();
echo $page->getHtml();
