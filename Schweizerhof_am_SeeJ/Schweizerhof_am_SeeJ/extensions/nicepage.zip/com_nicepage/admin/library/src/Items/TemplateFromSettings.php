<?php
/**
 * @package   Nicepage Website Builder
 * @author    Nicepage https://www.nicepage.com
 * @copyright Copyright (c) 2016 - 2019 Nicepage
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
 */

namespace NP\Items;

defined('_JEXEC') or die;

use \NicepageHelpersNicepage;
use NP\BaseItem;

/**
 * Class TemplateFromSettings
 */
class TemplateFromSettings extends BaseItem
{
    private $_name;
    private static $_instance;

    /**
     * @param string $name Template name
     */
    public function __construct($name) {
        $this->_name = $name;
        parent::__construct($this);
    }

    /**
     * Get template props
     * 
     * @return mixed|null
     */
    public function getProps() {
        $settings = NicepageHelpersNicepage::getParamsTable()->getParameters();
        $props = isset($settings[$this->_name]) ? $settings[$this->_name] : '';

        if (!$props) {
            return null;
        }

        $props = unserialize(call_user_func('base' . '64_decode', $props));
        $props['pageId'] = $this->_name;
        $props['isPreview'] = false;
        return $props;
    }

    /**
     * @return string
     */
    public function getHtml() {
        $type = $this->_pageView === 'landing' ? 'landing' : 'content';
        $content = "<!--np_" . $type . "-->" . $this->getSectionsHtml() . "<!--/np_" . $type . "-->";
        $content .= "<!--np_template_id-->" . $this->getPageId() . "<!--/np_template_id-->";
        return $content;
    }

    /**
     * Get edit link html
     *
     * @return string
     */
    public function getEditLinkHtml() {
        return '';
    }

    /**
     * Get page instance
     *
     * @param null $templateKey Template key
     *
     * @return TemplateFromSettings
     */
    public static function getInstance($templateKey)
    {
        if (!is_object(self::$_instance)) {
            self::$_instance = new self($templateKey);
        }

        return self::$_instance;
    }
}

