<?php
/**
 * @package   Nicepage Website Builder
 * @author    Nicepage https://www.nicepage.com
 * @copyright Copyright (c) 2016 - 2019 Nicepage
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
 */

namespace NP\Processor;

defined('_JEXEC') or die;

class PasswordProcessor
{
    /**
     * PasswordProcessor constructor.
     *
     * @param array $templateData Template data
     */
    public function __construct($templateData = null)
    {
        $this->_templateData = $templateData;
    }

    /**
     * Process login form
     *
     * @param string $content Content
     *
     * @return string|string[]|null
     */
    public function process($content) {
        $content = preg_replace_callback('/<\!--password_form-->([\s\S]+?)<\!--\/password_form-->/', array(&$this, '_processPasswordForm'), $content);
        return $content;
    }

    /**
     * Process password form
     *
     * @param array $passwordFormMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processPasswordForm($passwordFormMatch) {
        $passwordFormHtml = $passwordFormMatch[1];
        $passwordFormHtml = str_replace('action="#"', 'action="[[action]]"', $passwordFormHtml);
        $passwordFormHtml = str_replace('method="POST"', 'action="[[method]]"', $passwordFormHtml);
        $passwordFormHtml = preg_replace_callback('/<\!--password_form_input-->([\s\S]+?)<\!--\/password_form_input-->/', array(&$this, '_processPasswordFormInput'), $passwordFormHtml);
        return $passwordFormHtml;
    }

    /**
     * Process pasword form input
     *
     * @param array $inputMatch Matches
     *
     * @return string
     */
    private function _processPasswordFormInput($inputMatch) {
        $inputHtml = $inputMatch[1];
        return $inputHtml . '<input name="password_hash" id="hashbox" type="hidden" size="20">';
    }
}
