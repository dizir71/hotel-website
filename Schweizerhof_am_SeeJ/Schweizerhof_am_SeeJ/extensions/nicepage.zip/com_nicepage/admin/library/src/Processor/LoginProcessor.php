<?php
/**
 * @package   Nicepage Website Builder
 * @author    Nicepage https://www.nicepage.com
 * @copyright Copyright (c) 2016 - 2019 Nicepage
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
 */

namespace NP\Processor;

defined('_JEXEC') or die;

class LoginProcessor
{
    private $_templateData;

    /**
     * LoginProcessor constructor.
     *
     * @param array $templateData Template data
     */
    public function __construct($templateData = null)
    {
        $this->_templateData = $templateData;
    }

    /**
     * Process login form
     *
     * @param string $content Content
     *
     * @return string|string[]|null
     */
    public function process($content) {
        $content = preg_replace_callback('/<\!--login_form-->([\s\S]+?)<\!--\/login_form-->/', array(&$this, '_processLoginForm'), $content);
        $content = preg_replace_callback('/<\!--login_form_forgot_password-->([\s\S]+?)<\!--\/login_form_forgot_password-->/', array(&$this, '_processLoginFormForgotPassword'), $content);
        $content = preg_replace_callback('/<\!--login_form_forgot_name-->([\s\S]+?)<\!--\/login_form_forgot_name-->/', array(&$this, '_processLoginFormForgotName'), $content);
        $content = preg_replace_callback('/<\!--login_form_create_account-->([\s\S]+?)<\!--\/login_form_create_account-->/', array(&$this, '_processLoginFormCreateAccount'), $content);
        return $content;
    }

    /**
     * Process form
     *
     * @param array $loginFormMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginForm($loginFormMatch) {
        $loginFormHtml = $loginFormMatch[1];
        if (isset($this->_templateData['login_form_action'])) {
            $loginFormHtml = str_replace('action="#"', 'action="' . $this->_templateData['login_form_action'] . '"', $loginFormHtml);
        }
        if (isset($this->_templateData['hidden_fields'])) {
            $loginFormHtml = str_replace('</form>', $this->_templateData['hidden_fields'] . '</form>', $loginFormHtml);
        }
        if (isset($this->_templateData['loginFormClassPlaceholder'])) {
            $loginFormHtml = preg_replace('/class="([^"]*?u-inner-form[^"]*?)"/', '<!--loginFormClassPlaceholder-->$1<!--/loginFormClassPlaceholder-->', $loginFormHtml);
        }
        $loginFormHtml = preg_replace_callback('/<\!--login_form_passwordGroup-->([\s\S]+?)<\!--\/login_form_passwordGroup-->/', array(&$this, '_processLoginFormPasswordGroup'), $loginFormHtml);
        $loginFormHtml = preg_replace_callback('/<\!--login_form_usernameGroup-->([\s\S]+?)<\!--\/login_form_usernameGroup-->/', array(&$this, '_processLoginFormUsernameGroup'), $loginFormHtml);
        $loginFormHtml = preg_replace_callback('/<\!--login_form_rememberGroup-->([\s\S]+?)<\!--\/login_form_rememberGroup-->/', array(&$this, '_processLoginFormRememberGroup'), $loginFormHtml);
        $loginFormHtml = preg_replace_callback('/<\!--login_form_submit-->([\s\S]+?)<\!--\/login_form_submit-->/', array(&$this, '_processLoginFormSubmit'), $loginFormHtml);

        return $loginFormHtml;
    }

    /**
     * Process form submit
     *
     * @param array $submitMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormSubmit($submitMatch) {
        if (isset($this->_templateData['loginFormLogoutPlaceholder'])) {
            return '<!--loginFormLogoutPlaceholder-->' . $submitMatch[1] . '<!--/loginFormLogoutPlaceholder-->';
        }
        return $submitMatch[1];
    }

    /**
     * Process form remember group
     *
     * @param array $rememberGroupMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormRememberGroup($rememberGroupMatch) {
        $rememberGroupHtml = $rememberGroupMatch[1];
        $rememberGroupHtml = preg_replace_callback('/<\!--login_form_remember-->([\s\S]+?)<\!--\/login_form_remember-->/', array(&$this, '_processLoginFormRemember'), $rememberGroupHtml);
        $rememberGroupHtml = preg_replace_callback('/<\!--login_form_rememberLabel-->([\s\S]+?)<\!--\/login_form_rememberLabel-->/', array(&$this, '_processLoginFormRememberLabel'), $rememberGroupHtml);
        return $rememberGroupHtml;
    }

    /**
     * Process form checkbox remember
     *
     * @param array $rememberMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormRemember($rememberMatch) {
        return $rememberMatch[1];
    }

    /**
     * Process form remember label
     *
     * @param array $rememberLabelMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormRememberLabel($rememberLabelMatch) {
        return $rememberLabelMatch[1];
    }

    /**
     * Process form username group
     *
     * @param array $usernameGroupMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormUsernameGroup($usernameGroupMatch) {
        $usernameGroupHtml = $usernameGroupMatch[1];
        $usernameGroupHtml = preg_replace_callback('/<\!--login_form_username-->([\s\S]+?)<\!--\/login_form_username-->/', array(&$this, '_processLoginFormUsername'), $usernameGroupHtml);
        $usernameGroupHtml = preg_replace_callback('/<\!--login_form_usernameLabel-->([\s\S]+?)<\!--\/login_form_usernameLabel-->/', array(&$this, '_processLoginFormUsernameLabel'), $usernameGroupHtml);
        if (isset($this->_templateData['loginFormUsernameGroupTemplate'])) {
            return '<!--loginFormUsernameGroupTemplate-->' . $usernameGroupHtml . '<!--/loginFormUsernameGroupTemplate-->';
        }
        return $usernameGroupHtml;
    }

    /**
     * Process form input username
     *
     * @param array $usernameMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormUsername($usernameMatch) {
        $usernameHtml = $usernameMatch[1];
        if (isset($this->_templateData['loginFormUsernameGroupTemplate'])) {
            $usernameHtml = preg_replace('/type="[^"]+?"/', 'type="[[input_type]]"', $usernameHtml);
            $usernameHtml = preg_replace('/placeholder="[^"]+?"/', 'placeholder="[[input_placeholder]]"', $usernameHtml);
            $usernameHtml = preg_replace('/id="[^"]+?"/', 'id="[[input_id]]"', $usernameHtml);
            $usernameHtml = preg_replace('/name="[^"]+?"/', 'name="[[input_name]]"', $usernameHtml);
            return $usernameHtml;
        }
        return $usernameHtml;
    }

    /**
     * Process form username label
     *
     * @param array $usernameLabelMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormUsernameLabel($usernameLabelMatch) {
        $usernameLabelHtml = $usernameLabelMatch[1];
        if (isset($this->_templateData['loginFormUsernameGroupTemplate'])) {
            $usernameLabelHtml = preg_replace('/for="[^"]+?"/', 'for="[[label_for]]"', $usernameLabelHtml);
            $usernameLabelHtml = preg_replace('/name="[^"]+?"/', 'name="[[label_name]]"', $usernameLabelHtml);
            $usernameLabelHtml = preg_replace('/(<label[^>]+?>)([\s\S]*?)(<\/label>)/', '$1[[label_content]]$3', $usernameLabelHtml);
            return $usernameLabelHtml;
        }
        return $usernameLabelHtml;
    }

    /**
     * Process form password group
     *
     * @param array $passwordGroupMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormPasswordGroup($passwordGroupMatch) {
        $passwordGroupHtml = $passwordGroupMatch[1];
        $passwordGroupHtml = preg_replace_callback('/<\!--login_form_password-->([\s\S]+?)<\!--\/login_form_password-->/', array(&$this, '_processLoginFormPassword'), $passwordGroupHtml);
        $passwordGroupHtml = preg_replace_callback('/<\!--login_form_passwordLabel-->([\s\S]+?)<\!--\/login_form_passwordLabel-->/', array(&$this, '_processLoginFormPasswordLabel'), $passwordGroupHtml);
        return $passwordGroupHtml;
    }

    /**
     * Process form password label
     *
     * @param array $passwordLabelMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormPasswordLabel($passwordLabelMatch) {
        return $passwordLabelMatch[1];
    }

    /**
     * Process form input password
     *
     * @param array $passwordMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormPassword($passwordMatch) {
        $passwordHtml = $passwordMatch[1];
        $passwordHtml = str_replace('type="text"', 'type="password"', $passwordHtml);
        return $passwordHtml;
    }

    /**
     * Process form forgot password
     *
     * @param array $forgotPasswordMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormForgotPassword($forgotPasswordMatch) {
        $forgotPasswordHtml = $forgotPasswordMatch[1];
        if (isset($this->_templateData['login_remind_action'])) {
            $forgotPasswordHtml = str_replace('href="#"', 'href="' . $this->_templateData['login_remind_action'] . '"', $forgotPasswordHtml);
        }
        return $forgotPasswordHtml;
    }

    /**
     * Process form forgot name
     *
     * @param array $forgotNameMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormForgotName($forgotNameMatch) {
        $forgotNameHtml = $forgotNameMatch[1];
        if (isset($this->_templateData['login_reset_action'])) {
            $forgotNameHtml = str_replace('href="#"', 'href="' . $this->_templateData['login_reset_action'] . '"', $forgotNameHtml);
        }
        return $forgotNameHtml;
    }

    /**
     * Process create account
     *
     * @param array $createAccountMatch Matches
     *
     * @return array|string|string[]|null
     */
    private function _processLoginFormCreateAccount($createAccountMatch) {
        if (isset($this->_templateData['login_registration_allow']) && !$this->_templateData['login_registration_allow']) {
            return '';
        }
        $createAccountHtml = $createAccountMatch[1];
        if (isset($this->_templateData['login_registration_action'])) {
            $createAccountHtml = str_replace('href="#"', 'href="' . $this->_templateData['login_registration_action'] . '"', $createAccountHtml);
        }
        return $createAccountHtml;
    }
}
