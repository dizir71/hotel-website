<?php
/**
 * @package   Nicepage Website Builder
 * @author    Nicepage https://www.nicepage.com
 * @copyright Copyright (c) 2016 - 2019 Nicepage
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
 */

namespace NP\Utility;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Language\Text;

class Pagination
{
    private $_allPosts;
    private $_offset;
    private $_postsPerPage;
    private $_task;

    private $_pageLink;
    private $_styleOptions;

    /**
     * @param object $pagination Pagination object
     * @param array  $styles     Styles pagination
     *
     * @return array|false|mixed|string|string[]
     */
    public static function getTemplatePagination($pagination, $styles)
    {
        // Build the page navigation list.
        $data = $pagination->getData();

        $list           = [];
        $list['prefix'] = '';

        // Build the select list
        if ($data->all->base !== null) {
            $list['all']['active'] = true;
            $list['all']['data']   = self::getTemplateLink($data->all, true);
        } else {
            $list['all']['active'] = false;
            $list['all']['data']   = self::getTemplateLink($data->all, false);
        }

        if ($data->start->base !== null) {
            $list['start']['active'] = true;
            $list['start']['data']   = self::getTemplateLink($data->start, true);
        } else {
            $list['start']['active'] = false;
            $list['start']['data']   = self::getTemplateLink($data->start, false);
        }

        if ($data->previous->base !== null) {
            $list['previous']['active'] = true;
            $list['previous']['data']   = self::getTemplateLink($data->previous, true);
        } else {
            $list['previous']['active'] = false;
            $list['previous']['data']   = self::getTemplateLink($data->previous, false);
        }

        // Make sure it exists
        $list['pages'] = [];

        foreach ($data->pages as $i => $page) {
            if ($page->base !== null) {
                $list['pages'][$i]['active'] = true;
                $list['pages'][$i]['data']   = self::getTemplateLink($page, true);
            } else {
                $list['pages'][$i]['active'] = false;
                $list['pages'][$i]['data']   = self::getTemplateLink($page, false);
            }
        }

        if ($data->next->base !== null) {
            $list['next']['active'] = true;
            $list['next']['data']   = self::getTemplateLink($data->next, true);
        } else {
            $list['next']['active'] = false;
            $list['next']['data']   = self::getTemplateLink($data->next, false);
        }

        if ($data->end->base !== null) {
            $list['end']['active'] = true;
            $list['end']['data']   = self::getTemplateLink($data->end, true);
        } else {
            $list['end']['active'] = false;
            $list['end']['data']   = self::getTemplateLink($data->end, false);
        }

        if ($pagination->total > $pagination->limit) {
            return self::getTemplateList($list, $styles);
        } else {
            return '';
        }
    }

    /**
     * @param object $list   Pagination list
     * @param array  $styles Styles
     *
     * @return array|false|mixed|string|string[]
     */
    public static function getTemplateList($list, $styles) {
        $ul = str_replace('style1', 'style2', $styles['ul']);

        $li = $styles['li'];
        $li_active = str_replace('class="', 'class="active ', $li);
        $li_start = str_replace('class="', 'class="start ', $li);
        $li_prev = str_replace('class="', 'class="prev ', $li);
        $li_next = str_replace('class="', 'class="next ', $li);
        $li_end = str_replace('class="', 'class="end ', $li);

        $link = $styles['link'];

        ob_start();
        ?>
        <ul <?php echo $ul; ?>>
            <?php if ($list['start']['active']) : ?>
                <li <?php echo $li_start; ?>>
                    <?php echo $list['start']['data']; ?>
                </li>
            <?php endif; ?>
            <?php if ($list['previous']['active']) : ?>
                <li <?php echo $li_prev; ?>>
                    <?php echo $list['previous']['data']; ?>
                </li>
            <?php endif; ?>
            <?php foreach ($list['pages'] as $page) : ?>
                <?php echo '<li ' . ($page['active'] ? $li : $li_active) . '>' . $page['data'] . '</li>'; ?>
            <?php endforeach; ?>
            <?php if ($list['next']['active']) : ?>
                <li <?php echo $li_next; ?>><?php echo $list['next']['data']; ?></li>
            <?php endif; ?>
            <?php if ($list['end']['active']) : ?>
                <li <?php echo $li_end; ?>><?php echo $list['end']['data']; ?></li>
            <?php endif; ?>
        </ul>
        <?php
        $html = ob_get_clean();

        $html = str_replace('<a ', '<a ' . $link . ' ', $html);
        $html = str_replace('<span ', '<span ' . $link . ' ', $html);
        $html = str_replace(
            array('>' . Text::_('JLIB_HTML_START'), '>' . Text::_('JPREV'), '>' . Text::_('JNEXT'), '>' . Text::_('JLIB_HTML_END')),
            array('>' . '&#12298', '>' . '&#12296', '>' . '&#12297', '>' . '&#12299'),
            $html
        );
        return $html;
    }

    /**
     * @param object $item     Item
     * @param bool   $isActive Item active
     *
     * @return string
     */
    public static function getTemplateLink($item, $isActive) {
        $display = $item->text;
        $app = Factory::getApplication();

        switch ((string) $item->text)
        {
        case Text::_('JLIB_HTML_START'):
        case Text::_('JPREV'):
        case Text::_('JNEXT'):
        case Text::_('JLIB_HTML_END'):
            $aria = Text::sprintf('JLIB_HTML_GOTO_POSITION', strtolower($item->text));
            break;
        default:
            $aria = Text::sprintf('JLIB_HTML_GOTO_PAGE', strtolower($item->text));
            break;
        }

        if ($isActive) {
            if ($item->base > 0) {
                $limit = 'limitstart.value=' . $item->base;
            } else {
                $limit = 'limitstart.value=0';
            }

            $class = 'active';

            if ($app->isClient('administrator')) {
                $link = 'href="#" onclick="document.adminForm.' . $item->prefix . $limit . '; Joomla.submitform();return false;"';
            } elseif ($app->isClient('site')) {
                $link = 'href="' . $item->link . '"';
            }
        } else {
            $class = (property_exists($item, 'active') && $item->active) ? 'active' : 'disabled';
        }

        if ($isActive) {
            return '<a aria-label="' . $aria . '"' . $link . ' class="page-link">' . $display . '</a>';
        } elseif (isset($item->active) && $item->active) {
            $aria = Text::sprintf('JLIB_HTML_PAGE_CURRENT', strtolower($item->text));
            return '<span aria-current="true" aria-label="' . $aria .'" class="page-link">' . $display . '</span>';
        } else {
            return '<span class="page-link" aria-hidden="true">' . $display . '</span>';
        }
    }

    /**
     * Pagination constructor.
     *
     * @param array $options      Pagination options
     * @param array $styleOptions Pagination style options
     */
    public function __construct($options = array(), $styleOptions = array())
    {
        $this->_styleOptions = $styleOptions;

        $this->_allPosts = $options['allPosts'];
        $this->_offset = $options['offset'];
        $this->_postsPerPage = $options['postsPerPage'];
        $this->_task = $options['task'];
        $pageLink = '/index.php?option=com_nicepage&task=' . $this->_task . '&pageId=' . $options['pageId'];
        $this->_pageLink = $pageLink . '&position=' . $options['positionOnPage'] . '&order=' . $options['order'];

        $app = Factory::getApplication();
        $isPreview = $app->input->getBool('isPreview', false);
        if ($isPreview) {
            $this->_pageLink .= '&isPreview=true';
        }
    }

    /**
     * Get builded pagination
     *
     * @return false|mixed|string
     */
    public function getPagination()
    {
        $list = $this->_buildPagination();

        $ul = $this->_styleOptions['ul'];
        $ulSelector = 'u-pagination';
        if (preg_match('/class=[\'\"]([^\'\"]+?)[\'\"]/', $ul, $matches)) {
            $classesParts = explode(' ', $matches[1]);
            $ulSelector = '';
            foreach ($classesParts as $part) {
                $ulSelector .= '.' . trim($part);
            }
        }
        $li = $this->_styleOptions['li'];

        $li_active = str_replace('class="', 'class="active ', $li);
        $li_start = str_replace('class="', 'class="start ', $li);
        $li_prev = str_replace('class="', 'class="prev ', $li);
        $li_next = str_replace('class="', 'class="next ', $li);
        $li_end = str_replace('class="', 'class="end ', $li);

        $link = $this->_styleOptions['link'];

        ob_start();
        ?>
        <ul <?php echo $ul; ?>>
            <?php if ($list['start']['active']) : ?>
                <li <?php echo $li_start; ?>>
                    <?php echo $list['start']['data']; ?>
                </li>
            <?php endif; ?>
            <?php if ($list['previous']['active']) : ?>
                <li <?php echo $li_prev; ?>>
                    <?php echo $list['previous']['data']; ?>
                </li>
            <?php endif; ?>
            <?php foreach ($list['pages'] as $page) : ?>
                <?php echo '<li ' . ($page['active'] ? $li : $li_active) . '>' . $page['data'] . '</li>'; ?>
            <?php endforeach; ?>
            <?php if ($list['next']['active']) : ?>
                <li <?php echo $li_next; ?>><?php echo $list['next']['data']; ?></li>
            <?php endif; ?>
            <?php if ($list['end']['active']) : ?>
                <li <?php echo $li_end; ?>><?php echo $list['end']['data']; ?></li>
            <?php endif; ?>
        </ul>
        <script>
            jQuery(function ($) {
                $('<?php echo $ulSelector; ?> a').click(function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    var a = $(this);
                    var href = a.attr('href');
                    $.post(href).done(function (html) {
                        a.closest('.u-list-control').parent().replaceWith(html);
                    });
                })
            });
        </script>
        <?php
        $html = ob_get_clean();

        $html = str_replace('<a ', '<a ' . $link . ' ', $html);
        $html = str_replace('<span', '<span ' . $link . ' ', $html);
        return $html;
    }

    /**
     * Build pagination
     *
     * @return array
     */
    private function _buildPagination()
    {
        $list = array();
        $list['start'] = $this->_getStartLink();
        $list['previous'] = $this->_getPreviousLink();
        $list['pages'] = $this->_getPageLinks();
        $list['next'] = $this->_getNextLink();
        $list['end'] = $this->_getEndLink();
        return $list;
    }

    /**
     * Get start link
     *
     * @return array
     */
    private function _getStartLink()
    {
        if ($this->_offset == 0) {
            $active = false;
            $data = '<span>&#12298</span>';
        } else {
            $active = true;
            $startHref = Uri::root(true) . $this->_pageLink . '&offset=0';
            $data = '<a title="Start" href="' . $startHref . '">&#12298</a>';
        }
        return array(
            'active' => $active,
            'data' => $data,
        );
    }

    /**
     * Get previous link
     *
     * @return array
     */
    private function _getPreviousLink()
    {
        if ($this->_offset == 0) {
            $active = false;
            $data = '<span>&#12296</span>';
        } else {
            $active = true;
            $previousDiv = $this->_offset - $this->_postsPerPage;
            $previousOffset = $previousDiv > 0 ? $previousDiv : 0;
            $previousHref = Uri::root(true) . $this->_pageLink . '&offset=' . $previousOffset;
            $data = '<a title="Prev" href="' . $previousHref . '">&#12296</a>';
        }
        return array(
            'active' => $active,
            'data' => $data,
        );
    }

    /**
     * Get page links
     *
     * @return array
     */
    private function _getPageLinks()
    {
        $result = array();
        $all = $this->_allPosts;
        $limit = 0;
        $i = 1;
        $activeId = 1;
        while ($all > $limit) {
            if ($limit === $this->_offset) {
                $active = false;
                $data = '<span>' . $i .'</span>';
                $activeId = $i;
            } else {
                $active = true;
                $data = '<a href="' . Uri::root(true) . $this->_pageLink . '&offset=' . $limit . '">' . $i .'</a>';
            }
            array_push($result, array('active' => $active, 'data' => $data));
            $limit += $this->_postsPerPage;
            $i += 1;
        }

        $maxPages = 10;
        $halfMaxPages = 5;
        if (count($result) > $maxPages) {
            $leftSide = array_slice($result, 0, $activeId);
            $rightSide = array_slice($result, $activeId);
            if (count($leftSide) < $halfMaxPages) {
                $leftPart = $leftSide;
                $need = $maxPages - count($leftPart);
                $rightPart = array_slice($result, $activeId, $need);
            } else if (count($rightSide) < $halfMaxPages) {
                $rightPart = $rightSide;
                $need = $maxPages - count($rightPart);
                $leftPart = array_slice($result, $activeId - $need, $need);
            } else {
                $leftPart = array_slice($result, $activeId - $halfMaxPages, $halfMaxPages);
                $rightPart = array_slice($result, $activeId, $halfMaxPages);
            }
            $result = array_merge($leftPart, $rightPart);
        }
        return $result;
    }

    /**
     * Get next link
     *
     * @return array
     */
    private function _getNextLink()
    {
        $nextLimitStart = $this->_offset + $this->_postsPerPage;
        if ($nextLimitStart > $this->_allPosts) {
            $active = false;
            $data = '<span>&#12297</span>';
        } else {
            $active = true;
            $nextHref = Uri::root(true) . $this->_pageLink . '&offset=' . $nextLimitStart;
            $data = '<a title="Next" href="' . $nextHref . '">&#12297</a>';
        }
        return array(
            'active' => $active,
            'data' => $data,
        );
    }

    /**
     * Get end link
     *
     * @return array
     */
    private function _getEndLink()
    {
        $endLimitStart = $this->_offset + $this->_postsPerPage;
        if ($endLimitStart > $this->_allPosts) {
            $active = false;
            $data = '<span>&#12299</span>';
        } else {
            $active = true;
            $mod = $this->_allPosts % $this->_postsPerPage;
            $term = $mod === 0 ? $this->_postsPerPage : $mod;
            $endLimitStart = $this->_allPosts - $term;
            $endHref = Uri::root(true) . $this->_pageLink . '&offset=' . $endLimitStart;
            $data = '<a title="End" href="' . $endHref . '">&#12299</a>';
        }
        return array(
            'active' => $active,
            'data' => $data,
        );
    }
}
