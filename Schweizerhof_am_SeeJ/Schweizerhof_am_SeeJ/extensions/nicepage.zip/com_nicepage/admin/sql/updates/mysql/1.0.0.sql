CREATE TABLE IF NOT EXISTS `#__nicepage_templates` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `template_key` varchar(255) NOT NULL DEFAULT '',
    `props` mediumtext NOT NULL,
    `preview_props` mediumtext NOT NULL,
    `autosave_props` mediumtext NOT NULL,
    PRIMARY KEY (`id`)
);
