CREATE TABLE IF NOT EXISTS #__nicepage_templates (
    id serial NOT NULL,
    template_key character varying(255) DEFAULT '' NOT NULL ,
    props text DEFAULT '',
    preview_props text DEFAULT '',
    autosave_props text DEFAULT '',
    PRIMARY KEY (id)
);
