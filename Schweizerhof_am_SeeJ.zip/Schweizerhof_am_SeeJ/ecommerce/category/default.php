<?php
defined('_JEXEC') or die;

require_once dirname(dirname(dirname(__FILE__))) . '/functions.php';
include_once dirname(__FILE__) . '/custom_products_1.php';
