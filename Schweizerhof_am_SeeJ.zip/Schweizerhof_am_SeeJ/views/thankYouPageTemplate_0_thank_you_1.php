<section class="u-align-center u-clearfix u-container-align-center u-section-1" id="block-1">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <h2 class="u-align-center u-text u-text-default u-text-1"> Thank you for your order</h2>
    <p class="u-align-center u-text u-text-default u-text-2">Sample text. Click to select the Text Element.</p>
  </div>
</section>
