<div class="u-page-root"><section class="u-align-center u-clearfix u-section-1" id="sec-545f">
  <div class="u-align-left u-clearfix u-sheet u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1"></div>
  <style data-mode="XXL">@media (min-width: 1400px) {
  .u-section-1 .u-sheet-1 {
    min-height: 835px;
  }
}</style>
</section><section><?php $this->renderComponent(); ?></section></div>