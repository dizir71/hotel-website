<section class="u-align-center u-clearfix u-gradient u-section-1" id="carousel_377d">
  <div class="u-clearfix u-sheet u-sheet-1">
    <h1 class="u-custom-font u-font-georgia u-text u-text-default u-text-1">Latest News</h1><?php
$blogJson = '{"type":"Recent","source":"","tags":"","count":""}';
if ($all) { echo getGridAutoRowsStyles($blogJson, $all); }
?>

    <div class="u-blog u-expanded-width u-blog-1">
      <div class="u-repeater u-repeater-1">