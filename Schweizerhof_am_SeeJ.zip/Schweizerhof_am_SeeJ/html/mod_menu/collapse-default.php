<?php
defined('_JEXEC') or die;

require __DIR__ . '/default.php';