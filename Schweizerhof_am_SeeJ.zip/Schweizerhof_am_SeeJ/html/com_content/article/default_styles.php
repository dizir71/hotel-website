<style>
.u-section-1 .u-sheet-1 {
  min-height: 835px;
}
@media (max-width: 991px) {
  .u-section-1 .u-sheet-1 {
    min-height: 782px;
  }
}
@media (max-width: 767px) {
  .u-section-1 .u-sheet-1 {
    min-height: 722px;
  }
}
@media (max-width: 575px) {
  .u-section-1 .u-sheet-1 {
    min-height: 656px;
  }
}
</style>
